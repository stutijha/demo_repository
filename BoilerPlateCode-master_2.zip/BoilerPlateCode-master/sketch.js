function preload() {
  //load game assets
 
}


function setup() {
  createCanvas(600,600);
 
}

function draw() {
  background("black");  
  
}
